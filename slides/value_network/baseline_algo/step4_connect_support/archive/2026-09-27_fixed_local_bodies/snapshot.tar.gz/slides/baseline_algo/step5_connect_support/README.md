# Step5：局部头部身体与分散脚面

用户已认可当前形态作为后续设计基准。[设计思路与具体构造过程](local_body_design.md) 记录“同一块头部身体在另一姿态成为脚”的含义、本例实现和待做的优化。

先看 [逐步构造动画](../output/B/pose1+3/step5/construction.html)，可播放、暂停、拖动进度条和逐步切换。已导出 [双姿态同步视频](../output/B/pose1+3/step5/construction.mp4)、[Pose 1 视频](../output/B/pose1+3/step5/construction_pose1.mp4)、[Pose 3 视频](../output/B/pose1+3/step5/construction_pose3.mp4)，每段约 49 秒。20 个步骤依次显示原头、六块初始身体、八处补充脚端、四处短连接及完整实体；左右同步显示同一块新增材料。

当前 **B / pose1+3**：[总览](../output/B/pose1+3/step5/overview.png)、[交互模型](../output/B/pose1+3/step5/index.html)、[仅支架](../output/B/pose1+3/step5/fixture.png)、[同一局部身体的两种摆放](../output/B/pose1+3/step5/local_body.png)、[STL（mm）](../output/B/pose1+3/step5/fixture_mm.stl)。查看器可以选择六块局部身体之一，其余支架隐藏，用同一块真实几何比较两个任务中的位置；这不表示单块可以独立完成任务。

实体取消地面包围框。六块原头附近的身体分别向另一姿态的地面延伸；需要补充跨度的地方，用局部斜向 loft 形成脚端面。各脚面不沿外围连接，身体之间补四处地面上方的短连接。彩色仍仅标记头与附近区域，新增身体为灰白色。

本例体积 **141.426 cm³**，尺寸约 **198 × 196 × 110 mm**。比此前 60.803 cm³ 窄框大；它是局部角色复用的几何实验，不能称作已经省料或完成耦合优化。保留五组颜色／接触标识、**六块实际接触面**，橙色对应两个不同面；原工件任务姿态及各自三头接触保持。

## 怎样检查耦合

连成一件、共用颜色、相交体积大，均不足以说明局部材料复用。当前检查分开回答两个问题：

1. **同一局部身体是否直接连接两种功能面？** [几何见证](../output/B/pose1+3/step5/local_wedge_audit.json) 对六块身体均找到有面积的 head 子三角与另一姿态实际 floor 子三角；两端都在真实边界，整个直接三角楔经 Mesh64 布尔差检查包含于该身体和最终实体。这只证明这些小区域的直接几何关系，不代表整片头或整个身体都有效复用。
2. **这些接触是否对任务有作用？** [端口消融](../output/B/pose1+3/step5/local_role_audit.json) 保持几何不变，分别屏蔽该头、该身体在另一姿态独有的地面反力，再重新分配全部反力。其它身体和连接件仍提供的接触保留。原样本不可行可说明相应端口在当前模型中必要；全部通过则说明冗余，不能据此否定所有复用。整个身体的端口必要，不等于上一步选中的小三角本身必要。

本例六块头的接触均有必要性数值见证；其中 `body0`（pose1 橙头）、`body3`（pose3 橙头）、`body4`（pose3 青色头）的另一姿态独有落脚接触也有必要性见证。其余三块单独屏蔽该落脚接触后仍通过全部原样本，不表示可同时删除这三处。地面归属采用明确的 1 nm 公差，消除布尔差集留下的数值边界碎片，同时保护其它身体及连接件的接触；两姿态未消融的基线均重新通过全部原样本。失败见证由 simplex 与 IPM 同时报不可行，仍是数值证据。

现有无质量刚体模型不描述内部应力。因此这两项合起来仍不是应力复用、刚度、强度或等强度减材证明；较远的脚端延伸也不能仅因属于同一身体就自动算作局部耦合。进一步思考与有限摆放检查见 [设计记录](shared_design.md)。

## 构造中的实际改变

- 头背部约 8 mm 的扩展与另一落地面直接插值，构成原始局部身体；随后用八个脚端区域局部调整形状。拟合参数为本例选定值，保存在 [local_body_case.json](local_body_case.json)，不是全局最优解。
- 所有新增材料同时服从两地面和两完整装卸扫掠；0.4 mm relief 仅作用于新增身体，原头材料恢复后整件复验。
- 一度放在 pose3 `y≈0` 的左脚虽然孤立静力可行，却处于难以连接的窄空间。最终移到 `x=[−58,−50] mm, y=[16,28] mm`，直接接入 pose1 橙头身体。受力使用整件的实际落地面，包括另一姿态的身体自然形成的接触，未要求各 pose 单独配齐独立底座。
- 八个端面都由直接 loft 连接，没有采用绕障地框或格点路线。各局部身体可以重叠；`body0.obj` 至 `body5.obj` 是生成部件，`bridges.obj` 是必要连接，物理结果为它们的单一布尔并集。

## 验收与复现

最终实体封闭、连通，两姿态各 **32,768 / 32,768** 原样本通过；原头材料包含、接触面、两地面及完整连续退出通过。[独立回放](../output/B/pose1+3/step5/independent_audit.json) 从源头接触与实际落地顶点独立重建两刚体矩阵，重放全部 65,536 组反力。沿用无摩擦头、地面有限摩擦见证参数 64、忽略支架自重，不增加载荷或额外零加工力门槛。

[report.json](../output/B/pose1+3/step5/report.json) 是实体验收记录，[design.json](../output/B/pose1+3/step5/design.json) 保存脚端、身体和连接，[equilibrium.npz](../output/B/pose1+3/step5/equilibrium.npz) 保存反力证据。两个附加 audit 的输入哈希对应同一个实体报告；它们独立于主验收，不把科研诊断变成新的载荷验收条件。

```sh
OPENBLAS_NUM_THREADS=1 /Users/yuanboli/miniforge3/envs/cadgrasp/bin/python slides/baseline_algo/step5_connect_support/build_local_bodies.py
node slides/baseline_algo/step5_connect_support/export_shared_geometry.cjs
OPENBLAS_NUM_THREADS=1 /Users/yuanboli/miniforge3/envs/cadgrasp/bin/python slides/baseline_algo/step5_connect_support/audit_fixture.py
OPENBLAS_NUM_THREADS=1 /Users/yuanboli/miniforge3/envs/cadgrasp/bin/python slides/baseline_algo/step5_connect_support/audit_local_roles.py slides/baseline_algo/output/B/pose1+3/step5
OPENBLAS_NUM_THREADS=1 /Users/yuanboli/miniforge3/envs/cadgrasp/bin/python slides/baseline_algo/step5_connect_support/audit_local_wedges.py slides/baseline_algo/output/B/pose1+3/step5
```

`build_frame_union.py`、`build_coupled_saddle.py`、`build_shared_geometry.py` 保留此前窄框、厚体、杆／专用脚的构造代码，均非当前展示入口。

## 已有图解与动画

按用户要求，生成分步图和构造动画的辅助脚本、模板已删除。现有图片、视频、离线阅读页面和检查记录保留，仍可从本页顶部入口查看。实体生成器与验收代码继续使用上面的复现命令。

构造动画记录实际布尔新增材料，解释几何生成顺序；中间帧不表示可用支架、装配运动或制造过程。

历史检查记录中的生成器路径和哈希保留生成时的信息，不代表相应辅助代码仍在当前目录中；本次删除没有重新生成几何、图片或受力证据。

## 历史单 pose 工具与兼容入口

2026-09-17 已按当前要求拆分：

- [Step5：底座](../step5_base/README.md)：从 Step4 需求凸包和 Step3 全部共同方向生成紧凑、可插入的底座。
- [Step6：连接与视频](../step6_connect_support/README.md)：固定该底座和方向，连接原头，验证整件轨迹及承载，生成视频。

本目录保留共享几何、扫掠、反力验证和绘图工具。`belt_assembly.py`、`direction_first.py` 是 Step6 的兼容导入，旧命令入口转向当前 Step6 实现；运行前须先生成 Step5 底座。

原 `output/<object>/<pose>/step5_connect_support/` 文件保留为历史证据，不是新版最终结果。新版输出分别在 `step5_base/` 和 `step6_connect_support/`。全部代码与输出仍使用 Z-up、米制，毫米 STL 明确命名为 `_mm.stl`。
